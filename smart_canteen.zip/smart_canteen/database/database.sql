-- ============================================
-- database.sql
-- Smart Canteen - NMIMS Aditi Canteen
-- This file contains all SQL commands to create
-- the database tables and add sample data
--
-- To use this file:
-- 1. Open phpMyAdmin or MySQL Workbench
-- 2. Create a new database called "smart_canteen"
-- 3. Copy and run these SQL commands
-- ============================================


-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS smart_canteen;

-- Step 2: Use this database
USE smart_canteen;


-- ============================================
-- TABLE 1: students
-- Stores student login credentials
-- The 3 required fields are: id, sap_id, password
-- ============================================

CREATE TABLE students (
    id          INT AUTO_INCREMENT PRIMARY KEY,   -- Unique number for each student (auto increases)
    sap_id      VARCHAR(20) NOT NULL UNIQUE,       -- SAP ID like 60004230001 (must be unique)
    student_id  VARCHAR(20) NOT NULL,              -- Roll number like 23BCE1234
    password    VARCHAR(255) NOT NULL,             -- Student password
    full_name   VARCHAR(100) NOT NULL,             -- Student full name
    mobile      VARCHAR(15),                       -- Mobile number
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP -- When account was created
);


-- ============================================
-- TABLE 2: menu_items
-- Stores all food items in the canteen
-- ============================================

CREATE TABLE menu_items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    category    VARCHAR(50) NOT NULL,              -- breakfast, main, snacks, drinks
    price       INT NOT NULL,                      -- Price in Rupees
    description VARCHAR(255),
    food_type   VARCHAR(10) DEFAULT 'veg',         -- veg or nonveg
    is_available TINYINT DEFAULT 1                 -- 1 means available, 0 means not available
);


-- ============================================
-- TABLE 3: orders
-- Stores all placed orders by students
-- ============================================

CREATE TABLE orders (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    order_id        VARCHAR(20) NOT NULL UNIQUE,     -- Like ORD1234
    student_sap_id  VARCHAR(20) NOT NULL,            -- Which student placed the order
    total_amount    INT NOT NULL,                    -- Total amount paid
    delivery_location VARCHAR(100) NOT NULL,         -- Girls Hostel, Boys Hostel, Classroom
    payment_method  VARCHAR(20) NOT NULL,            -- upi, card, cod
    status          VARCHAR(50) DEFAULT 'Order Placed',
    ordered_at      DATETIME DEFAULT CURRENT_TIMESTAMP,

    -- Link this order to the students table using SAP ID
    FOREIGN KEY (student_sap_id) REFERENCES students(sap_id)
);


-- ============================================
-- TABLE 4: order_items
-- Stores which food items are in each order
-- (One order can have many food items)
-- ============================================

CREATE TABLE order_items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    order_id    VARCHAR(20) NOT NULL,     -- Which order this item belongs to
    item_name   VARCHAR(100) NOT NULL,    -- Name of the food
    quantity    INT NOT NULL,             -- How many of this item
    price       INT NOT NULL,             -- Price per item
    subtotal    INT NOT NULL              -- quantity x price
);


-- ============================================
-- TABLE 5: contact_messages
-- Stores messages sent from the contact page
-- ============================================

CREATE TABLE contact_messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    sap_id      VARCHAR(20),
    message     TEXT NOT NULL,
    sent_at     DATETIME DEFAULT CURRENT_TIMESTAMP
);


-- ============================================
-- SAMPLE DATA - Add some students for testing
-- These students can login with these credentials
-- ============================================

-- Insert 3 sample students
-- Fields: id, sap_id, student_id, password, full_name, mobile

INSERT INTO students (sap_id, student_id, password, full_name, mobile) VALUES
('60004230001', '23BCE1234', 'pass123', 'Priya Sharma',   '9876543210'),
('60004230002', '23BCE1235', 'pass456', 'Rahul Mehta',    '9876543211'),
('60004230003', '23BCE1236', 'pass789', 'Ananya Patel',   '9876543212');


-- ============================================
-- SAMPLE DATA - Add all the menu items
-- ============================================

INSERT INTO menu_items (name, category, price, description, food_type) VALUES
-- Breakfast
('Masala Dosa',          'breakfast', 60,  'Crispy dosa with spicy potato filling',                'veg'),
('Poha',                 'breakfast', 35,  'Flattened rice with onion and mustard seeds',          'veg'),
('Upma',                 'breakfast', 40,  'Semolina with vegetables and spices',                  'veg'),

-- Main Course
('Paneer Butter Masala', 'main',      130, 'Rich tomato gravy with paneer cubes and rice',         'veg'),
('Dal Tadka + Rice',     'main',      90,  'Yellow dal with tempered spices served with rice',     'veg'),
('Chicken Curry',        'main',      150, 'Home style spicy chicken curry with rice',             'nonveg'),
('Veg Biryani',          'main',      110, 'Fragrant basmati rice with mixed vegetables',          'veg'),

-- Snacks
('Samosa (2 pieces)',    'snacks',    30,  'Crispy pastry with spiced potato filling',             'veg'),
('Vada Pav',             'snacks',    25,  'Mumbai style spicy potato burger',                     'veg'),
('French Fries',         'snacks',    70,  'Crispy golden fries with ketchup',                     'veg'),
('Maggi Noodles',        'snacks',    45,  'The classic 2 minute favourite',                       'veg'),

-- Drinks
('Masala Chai',          'drinks',    15,  'Hot masala tea freshly made',                          'veg'),
('Cold Coffee',          'drinks',    55,  'Chilled blended coffee with ice cream',                'veg'),
('Nimbu Pani',           'drinks',    20,  'Fresh lemonade with mint leaves',                      'veg');


-- ============================================
-- USEFUL SELECT QUERIES (to check your data)
-- Run these anytime to see what is saved
-- ============================================

-- See all students
SELECT id, sap_id, student_id, full_name, mobile FROM students;

-- Login check: Find student with matching sap_id and password
-- (Replace the values with actual input)
SELECT * FROM students WHERE sap_id = '60004230001' AND password = 'pass123';

-- See all menu items
SELECT * FROM menu_items;

-- See all orders
SELECT * FROM orders ORDER BY ordered_at DESC;

-- See full order details with student name
SELECT
    o.order_id,
    s.full_name,
    s.sap_id,
    o.total_amount,
    o.delivery_location,
    o.payment_method,
    o.status,
    o.ordered_at
FROM orders o
JOIN students s ON o.student_sap_id = s.sap_id
ORDER BY o.ordered_at DESC;
