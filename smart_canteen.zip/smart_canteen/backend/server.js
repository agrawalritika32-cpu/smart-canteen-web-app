// ============================================
// server.js
// Smart Canteen - Backend Server using Node.js
//
// This file runs on the server side.
// It connects to MySQL database and handles:
// - Student login check
// - Student registration
// - Saving orders
// - Getting menu items
//
// HOW TO RUN THIS FILE:
// 1. Install Node.js from https://nodejs.org
// 2. Open terminal/command prompt in this folder
// 3. Run: npm install express mysql2 cors
// 4. Run: node server.js
// 5. Server starts on http://localhost:3000
// ============================================


// Import required packages
// "express" lets us create a web server
// "mysql2" lets us connect to MySQL database
// "cors" allows the HTML pages to talk to this server
var express = require("express");
var mysql   = require("mysql2");
var cors    = require("cors");

// Create the express app
var app = express();

// Allow JSON data to be sent to this server
app.use(express.json());

// Allow the HTML pages (running on any port) to call this server
app.use(cors());


// ============================================
// DATABASE CONNECTION
// Change the values below to match your MySQL setup
// ============================================

var db = mysql.createConnection({
    host:     "localhost",   // Usually localhost
    user:     "root",        // Your MySQL username
    password: "",            // Your MySQL password (leave empty if no password)
    database: "smart_canteen"  // Database name we created in database.sql
});

// Try to connect to the database
db.connect(function(err) {
    if (err) {
        console.log("ERROR: Could not connect to MySQL database.");
        console.log("Make sure MySQL is running and smart_canteen database exists.");
        console.log(err.message);
    } else {
        console.log("SUCCESS: Connected to MySQL database!");
    }
});


// ============================================
// ROUTE 1: Test if server is running
// Open http://localhost:3000 in browser to test
// ============================================

app.get("/", function(req, res) {
    res.send("Smart Canteen server is running!");
});


// ============================================
// ROUTE 2: Student Login
// URL: POST http://localhost:3000/login
// Checks if sap_id and password match in database
// ============================================

app.post("/login", function(req, res) {

    // Get the values sent from the login form
    var sapId    = req.body.sapId;
    var password = req.body.password;

    // Check if both are provided
    if (!sapId || !password) {
        return res.json({ success: false, message: "SAP ID and password are required." });
    }

    // SQL query to find matching student
    // The ? marks are replaced safely to prevent SQL injection
    var sql = "SELECT * FROM students WHERE sap_id = ? AND password = ?";

    db.query(sql, [sapId, password], function(err, results) {
        if (err) {
            return res.json({ success: false, message: "Database error." });
        }

        if (results.length == 0) {
            // No matching student found
            return res.json({ success: false, message: "Wrong SAP ID or password." });
        }

        // Student found - login successful
        var student = results[0];
        return res.json({
            success: true,
            message: "Login successful!",
            student: {
                id:        student.id,
                sapId:     student.sap_id,
                studentId: student.student_id,
                name:      student.full_name
            }
        });
    });
});


// ============================================
// ROUTE 3: Student Registration
// URL: POST http://localhost:3000/register
// Saves new student to database
// ============================================

app.post("/register", function(req, res) {

    var name      = req.body.name;
    var sapId     = req.body.sapId;
    var studentId = req.body.studentId;
    var mobile    = req.body.mobile;
    var password  = req.body.password;

    // Basic check
    if (!name || !sapId || !studentId || !password) {
        return res.json({ success: false, message: "All fields are required." });
    }

    // Check if SAP ID already exists
    var checkSql = "SELECT id FROM students WHERE sap_id = ?";

    db.query(checkSql, [sapId], function(err, results) {
        if (err) {
            return res.json({ success: false, message: "Database error." });
        }

        if (results.length > 0) {
            return res.json({ success: false, message: "SAP ID already registered." });
        }

        // Insert new student into database
        var insertSql = "INSERT INTO students (sap_id, student_id, password, full_name, mobile) VALUES (?, ?, ?, ?, ?)";

        db.query(insertSql, [sapId, studentId, password, name, mobile], function(err2, result) {
            if (err2) {
                return res.json({ success: false, message: "Could not register. Try again." });
            }

            return res.json({ success: true, message: "Registration successful!" });
        });
    });
});


// ============================================
// ROUTE 4: Get all menu items
// URL: GET http://localhost:3000/menu
// Returns all food items from the database
// ============================================

app.get("/menu", function(req, res) {

    var sql = "SELECT * FROM menu_items WHERE is_available = 1";

    db.query(sql, function(err, results) {
        if (err) {
            return res.json({ success: false, message: "Could not get menu." });
        }
        return res.json({ success: true, menu: results });
    });
});


// ============================================
// ROUTE 5: Save a new order
// URL: POST http://localhost:3000/place-order
// Saves order and order items to database
// ============================================

app.post("/place-order", function(req, res) {

    var sapId    = req.body.sapId;
    var total    = req.body.total;
    var location = req.body.location;
    var payment  = req.body.payment;
    var items    = req.body.items;   // Array of cart items
    var orderId  = "ORD" + Math.floor(Math.random() * 9000 + 1000);

    // Insert into orders table
    var orderSql = "INSERT INTO orders (order_id, student_sap_id, total_amount, delivery_location, payment_method) VALUES (?, ?, ?, ?, ?)";

    db.query(orderSql, [orderId, sapId, total, location, payment], function(err) {
        if (err) {
            return res.json({ success: false, message: "Could not place order." });
        }

        // Insert each item into order_items table
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var subtotal = item.price * item.quantity;
            var itemSql = "INSERT INTO order_items (order_id, item_name, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)";
            db.query(itemSql, [orderId, item.name, item.quantity, item.price, subtotal]);
        }

        return res.json({ success: true, orderId: orderId, message: "Order placed successfully!" });
    });
});


// ============================================
// ROUTE 6: Get order history for a student
// URL: GET http://localhost:3000/orders/:sapId
// ============================================

app.get("/orders/:sapId", function(req, res) {

    var sapId = req.params.sapId;

    var sql = "SELECT * FROM orders WHERE student_sap_id = ? ORDER BY ordered_at DESC";

    db.query(sql, [sapId], function(err, results) {
        if (err) {
            return res.json({ success: false, message: "Could not get orders." });
        }
        return res.json({ success: true, orders: results });
    });
});


// ============================================
// START THE SERVER
// This makes the server listen on port 3000
// ============================================

app.listen(3000, function() {
    console.log("Smart Canteen server is running on http://localhost:3000");
    console.log("Open your browser and go to http://localhost:3000 to test");
});
