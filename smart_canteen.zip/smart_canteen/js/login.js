// ============================================
// login.js
// This file handles the login page functionality
// When student clicks Login button, this code runs
// ============================================


// This function runs when the student clicks the "Login" button
function loginStudent() {

    // Step 1: Get the values the user typed in the form
    var sapId = document.getElementById("sapId").value;
    var studentId = document.getElementById("studentId").value;
    var password = document.getElementById("password").value;

    // Step 2: Get the element where we will show error messages
    var errorMsg = document.getElementById("errorMsg");

    // Step 3: Clear any old error message
    errorMsg.innerText = "";

    // Step 4: Check if all fields are filled
    if (sapId == "") {
        errorMsg.innerText = "Please enter your SAP ID.";
        return;
    }

    if (studentId == "") {
        errorMsg.innerText = "Please enter your Student ID.";
        return;
    }

    if (password == "") {
        errorMsg.innerText = "Please enter your password.";
        return;
    }

    // Step 5: Check if SAP ID is numbers only and has 11 digits
    if (sapId.length < 8) {
        errorMsg.innerText = "SAP ID looks too short. Please check.";
        return;
    }

    // Step 6: Get all registered users from localStorage
    // localStorage is like a small database that saves data in the browser
    var allUsers = localStorage.getItem("canteenUsers");

    // Step 7: If no users are registered yet, show a message
    if (allUsers == null) {
        errorMsg.innerText = "No account found. Please register first.";
        return;
    }

    // Step 8: Convert the saved text back to a JavaScript object (array)
    var usersArray = JSON.parse(allUsers);

    // Step 9: Search for a matching user
    var foundUser = null;

    for (var i = 0; i < usersArray.length; i++) {
        // Check if sapId, studentId AND password all match
        if (usersArray[i].sapId == sapId && usersArray[i].studentId == studentId && usersArray[i].password == password) {
            foundUser = usersArray[i];
            break;
        }
    }

    // Step 10: If no matching user found, show error
    if (foundUser == null) {
        errorMsg.innerText = "Wrong SAP ID, Student ID or Password. Please try again.";
        return;
    }

    // Step 11: Login successful! Save who is logged in
    // We save the logged in user info so other pages can use it
    localStorage.setItem("loggedInUser", JSON.stringify(foundUser));

    // Step 12: Go to the menu page
    alert("Login successful! Welcome, " + foundUser.name + "!");
    window.location.href = "menu.html";

}
