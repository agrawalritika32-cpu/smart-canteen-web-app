// ============================================
// menu.js
// This file handles the menu page
// - Shows welcome message
// - Filters food by category
// - Add to cart
// - Remove from cart
// - Shows cart total
// ============================================


// cart is an array to store items added by the student
var cart = [];


// This runs automatically when the page loads
window.onload = function() {

    // Check if a user is logged in
    var loggedInUser = localStorage.getItem("loggedInUser");

    if (loggedInUser == null) {
        // Nobody is logged in - send them to login page
        alert("Please login first to order food.");
        window.location.href = "index.html";
        return;
    }

    // Show welcome message with student name
    var user = JSON.parse(loggedInUser);
    document.getElementById("welcomeMsg").innerText = "Welcome, " + user.name + "!  SAP ID: " + user.sapId;

    // Show the classroom input if classroom is selected
    // Add event listener to all radio buttons
    var radioButtons = document.getElementsByName("location");
    for (var i = 0; i < radioButtons.length; i++) {
        radioButtons[i].addEventListener("change", function() {
            if (this.value == "Classroom") {
                document.getElementById("classroomInput").style.display = "block";
            } else {
                document.getElementById("classroomInput").style.display = "none";
            }
        });
    }

};


// ---- FILTER FOOD BY CATEGORY ----
// This function shows only the selected category of food cards
function filterFood(category, clickedButton) {

    // Remove the active class from all filter buttons
    var allButtons = document.getElementsByClassName("filter-btn");
    for (var i = 0; i < allButtons.length; i++) {
        allButtons[i].classList.remove("active-filter");
    }

    // Add active class to the button that was clicked
    clickedButton.classList.add("active-filter");

    // Get all food cards
    var allCards = document.getElementsByClassName("food-card");

    // Loop through all cards
    for (var i = 0; i < allCards.length; i++) {

        // If category is "all" show everything
        if (category == "all") {
            allCards[i].style.display = "block";
        }

        // Otherwise only show cards that match the selected category
        else if (allCards[i].getAttribute("data-category") == category) {
            allCards[i].style.display = "block";
        }

        // Hide cards that don't match
        else {
            allCards[i].style.display = "none";
        }
    }
}


// ---- ADD ITEM TO CART ----
function addToCart(itemName, itemPrice) {

    // Check if item is already in cart
    var alreadyInCart = false;

    for (var i = 0; i < cart.length; i++) {
        if (cart[i].name == itemName) {
            // Item already in cart, increase quantity by 1
            cart[i].quantity = cart[i].quantity + 1;
            alreadyInCart = true;
            break;
        }
    }

    // If item was not in cart, add it as a new item
    if (alreadyInCart == false) {
        var newItem = {
            name: itemName,
            price: itemPrice,
            quantity: 1
        };
        cart.push(newItem);
    }

    // Update the cart display on screen
    updateCartDisplay();

    // Show a small confirmation message
    alert(itemName + " added to cart!");
}


// ---- UPDATE THE CART DISPLAY ON SCREEN ----
function updateCartDisplay() {

    // Get the cart container element
    var cartContainer = document.getElementById("cartItems");

    // If cart is empty, show empty message
    if (cart.length == 0) {
        cartContainer.innerHTML = '<p id="emptyCartMsg">Your cart is empty. Add some food items above!</p>';
        document.getElementById("cartTotal").style.display = "none";
        document.getElementById("deliverySection").style.display = "none";
        return;
    }

    // Cart has items - build the HTML for each cart item
    var cartHTML = "";
    var totalAmount = 0;

    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        var itemTotal = item.price * item.quantity;
        totalAmount = totalAmount + itemTotal;

        cartHTML = cartHTML + '<div class="cart-item-row">';
        cartHTML = cartHTML + '<span>' + item.name + ' x ' + item.quantity + '</span>';
        cartHTML = cartHTML + '<span>Rs. ' + itemTotal + '</span>';
        cartHTML = cartHTML + '<button class="btn-remove" onclick="removeFromCart(' + i + ')">Remove</button>';
        cartHTML = cartHTML + '</div>';
    }

    // Put the cart HTML into the page
    cartContainer.innerHTML = cartHTML;

    // Show the total amount
    document.getElementById("totalAmount").innerText = totalAmount;
    document.getElementById("cartTotal").style.display = "block";

    // Show the delivery section
    document.getElementById("deliverySection").style.display = "block";
}


// ---- REMOVE AN ITEM FROM CART ----
function removeFromCart(index) {

    // Remove the item at the given position in the cart array
    cart.splice(index, 1);

    // Update the display
    updateCartDisplay();
}


// ---- PROCEED TO PAYMENT ----
function goToPayment() {

    // Check if cart has items
    if (cart.length == 0) {
        document.getElementById("locationError").innerText = "Your cart is empty!";
        return;
    }

    // Check if a delivery location is selected
    var selectedLocation = "";
    var radioButtons = document.getElementsByName("location");

    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].checked) {
            selectedLocation = radioButtons[i].value;
            break;
        }
    }

    if (selectedLocation == "") {
        document.getElementById("locationError").innerText = "Please select a delivery location.";
        return;
    }

    // If classroom selected, get the classroom number
    if (selectedLocation == "Classroom") {
        var classroomNo = document.getElementById("classroomNo").value;
        if (classroomNo == "") {
            document.getElementById("locationError").innerText = "Please enter your classroom number.";
            return;
        }
        selectedLocation = "Classroom - " + classroomNo;
    }

    // Save cart and location to localStorage so payment page can read it
    localStorage.setItem("cartItems", JSON.stringify(cart));
    localStorage.setItem("deliveryLocation", selectedLocation);

    // Calculate total
    var total = 0;
    for (var i = 0; i < cart.length; i++) {
        total = total + cart[i].price * cart[i].quantity;
    }
    localStorage.setItem("cartTotal", total);

    // Go to payment page
    window.location.href = "payment.html";
}
