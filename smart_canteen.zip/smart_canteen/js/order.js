// ============================================
// order.js
// This file handles the order tracking page
// - Shows order confirmation
// - Shows live tracking steps
// - Shows order history
// ============================================


// Track which step we are on
var currentStep = 1;
var trackingInterval;


// This runs when the page loads
window.onload = function() {

    // Check if user is logged in
    var loggedInUser = localStorage.getItem("loggedInUser");
    if (loggedInUser == null) {
        alert("Please login first.");
        window.location.href = "index.html";
        return;
    }

    // Check if there is a current order to show
    var currentOrderId = localStorage.getItem("currentOrderId");
    var currentLocation = localStorage.getItem("currentLocation");

    if (currentOrderId != null) {
        // Show the confirmation box
        document.getElementById("confirmationBox").style.display = "block";
        document.getElementById("confirmOrderId").innerText = currentOrderId;
        document.getElementById("confirmLocation").innerText = currentLocation;

        // Show tracking steps
        document.getElementById("trackingBox").style.display = "block";

        // Start the auto tracking (step updates every 5 seconds for demo)
        startTracking();

        // Clear the current order after showing it
        localStorage.removeItem("currentOrderId");
        localStorage.removeItem("currentLocation");
    }

    // Show order history
    showOrderHistory();
};


// ---- START THE TRACKING ANIMATION ----
// This simulates the order moving through steps
function startTracking() {

    currentStep = 1;
    updateTrackingStep(1);

    // Automatically advance to next step every 5 seconds (for demo purposes)
    trackingInterval = setInterval(function() {
        currentStep = currentStep + 1;

        if (currentStep <= 5) {
            updateTrackingStep(currentStep);
        } else {
            // Stop when all steps are done
            clearInterval(trackingInterval);
        }
    }, 5000);  // 5000 milliseconds = 5 seconds
}


// ---- UPDATE WHICH STEP IS HIGHLIGHTED ----
function updateTrackingStep(stepNumber) {

    // Loop through all 5 steps
    for (var i = 1; i <= 5; i++) {
        var stepElement = document.getElementById("step" + i);
        var circleElement = stepElement.getElementsByClassName("step-circle")[0];

        if (i < stepNumber) {
            // Past steps - show as done (green)
            stepElement.classList.add("step-done");
            circleElement.innerText = "✓";
        }
        else if (i == stepNumber) {
            // Current step - highlight it
            stepElement.classList.add("step-done");
            circleElement.innerText = "✓";
        }
        else {
            // Future steps - grey
            stepElement.classList.remove("step-done");
            circleElement.innerText = i;
        }
    }
}


// ---- SHOW ORDER HISTORY ----
function showOrderHistory() {

    var historyContainer = document.getElementById("orderHistoryList");
    var loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));

    // Get all orders from localStorage
    var allOrders = localStorage.getItem("orderHistory");

    if (allOrders == null) {
        historyContainer.innerHTML = "<p>No past orders found.</p>";
        return;
    }

    var ordersArray = JSON.parse(allOrders);

    // Filter only the logged in student's orders using SAP ID
    var myOrders = [];
    for (var i = 0; i < ordersArray.length; i++) {
        if (ordersArray[i].sapId == loggedInUser.sapId) {
            myOrders.push(ordersArray[i]);
        }
    }

    if (myOrders.length == 0) {
        historyContainer.innerHTML = "<p>No past orders found.</p>";
        return;
    }

    // Build HTML to show orders in reverse (newest first)
    var historyHTML = "";

    for (var i = myOrders.length - 1; i >= 0; i--) {
        var order = myOrders[i];

        // Build list of items ordered
        var itemsList = "";
        for (var j = 0; j < order.items.length; j++) {
            itemsList = itemsList + order.items[j].name + " x" + order.items[j].quantity + ", ";
        }
        // Remove the last comma and space
        itemsList = itemsList.slice(0, -2);

        historyHTML = historyHTML + '<div class="order-history-card">';
        historyHTML = historyHTML + '<p><strong>Order ID: </strong>' + order.orderId + '</p>';
        historyHTML = historyHTML + '<p><strong>Date: </strong>' + order.date + '  at  ' + order.time + '</p>';
        historyHTML = historyHTML + '<p><strong>Items: </strong>' + itemsList + '</p>';
        historyHTML = historyHTML + '<p><strong>Delivery To: </strong>' + order.location + '</p>';
        historyHTML = historyHTML + '<p><strong>Payment: </strong>' + order.paymentMethod.toUpperCase() + '</p>';
        historyHTML = historyHTML + '<p><strong>Total Paid: </strong>Rs. ' + order.total + '</p>';
        historyHTML = historyHTML + '<p><strong>Status: </strong>Delivered</p>';
        historyHTML = historyHTML + '</div>';
    }

    historyContainer.innerHTML = historyHTML;
}
