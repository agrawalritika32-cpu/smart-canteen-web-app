// ============================================
// payment.js
// This file handles the payment page
// - Shows order summary
// - Shows different payment forms
// - Places the order on payment
// ============================================


// This runs when the page loads
window.onload = function() {

    // Check if user is logged in
    var loggedInUser = localStorage.getItem("loggedInUser");
    if (loggedInUser == null) {
        alert("Please login first.");
        window.location.href = "index.html";
        return;
    }

    // Get cart data from localStorage (saved by menu.js)
    var cartItems = localStorage.getItem("cartItems");
    var deliveryLocation = localStorage.getItem("deliveryLocation");
    var cartTotal = localStorage.getItem("cartTotal");

    // If no cart data found, go back to menu
    if (cartItems == null) {
        alert("No items in cart. Please add food first.");
        window.location.href = "menu.html";
        return;
    }

    // Convert cart text back to array
    var cart = JSON.parse(cartItems);

    // Show the order summary on the page
    var summaryHTML = "";
    for (var i = 0; i < cart.length; i++) {
        var item = cart[i];
        summaryHTML = summaryHTML + "<p>" + item.name + "  x" + item.quantity + "  =  Rs. " + (item.price * item.quantity) + "</p>";
    }
    document.getElementById("summaryItems").innerHTML = summaryHTML;

    // Show location and total
    document.getElementById("summaryLocation").innerText = deliveryLocation;
    document.getElementById("summaryTotal").innerText = cartTotal;

};


// ---- SHOW THE RIGHT PAYMENT FORM ----
// This runs when student clicks on UPI, Card, or COD
function showPaymentForm(paymentType) {

    // First hide all 3 forms
    document.getElementById("upiForm").style.display = "none";
    document.getElementById("cardForm").style.display = "none";
    document.getElementById("codForm").style.display = "none";

    // Show only the form matching the selected payment type
    if (paymentType == "upi") {
        document.getElementById("upiForm").style.display = "block";
    }

    if (paymentType == "card") {
        document.getElementById("cardForm").style.display = "block";
    }

    if (paymentType == "cod") {
        document.getElementById("codForm").style.display = "block";
    }
}


// ---- PROCESS PAYMENT AND PLACE ORDER ----
function processPayment() {

    var errorMsg = document.getElementById("paymentError");
    errorMsg.innerText = "";

    // Step 1: Check which payment method is selected
    var selectedPayment = "";
    var radioButtons = document.getElementsByName("payment");

    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].checked) {
            selectedPayment = radioButtons[i].value;
            break;
        }
    }

    // If no payment method selected
    if (selectedPayment == "") {
        errorMsg.innerText = "Please select a payment method.";
        return;
    }

    // Step 2: Validate UPI form if UPI is selected
    if (selectedPayment == "upi") {
        var upiId = document.getElementById("upiId").value;
        if (upiId == "") {
            errorMsg.innerText = "Please enter your UPI ID.";
            return;
        }
        if (upiId.indexOf("@") == -1) {
            errorMsg.innerText = "UPI ID must contain @ symbol. Example: name@okicici";
            return;
        }
    }

    // Step 3: Validate Card form if Card is selected
    if (selectedPayment == "card") {
        var cardNo = document.getElementById("cardNo").value;
        var cardName = document.getElementById("cardName").value;
        var expiry = document.getElementById("expiry").value;
        var cvv = document.getElementById("cvv").value;

        if (cardNo == "") {
            errorMsg.innerText = "Please enter your card number.";
            return;
        }
        if (cardNo.length < 12) {
            errorMsg.innerText = "Card number must be at least 12 digits.";
            return;
        }
        if (cardName == "") {
            errorMsg.innerText = "Please enter the name on your card.";
            return;
        }
        if (expiry == "") {
            errorMsg.innerText = "Please enter the expiry date.";
            return;
        }
        if (cvv == "") {
            errorMsg.innerText = "Please enter the CVV.";
            return;
        }
        if (cvv.length < 3) {
            errorMsg.innerText = "CVV must be 3 digits.";
            return;
        }
    }

    // Step 4: All validations passed - Place the order

    // Get current date and time
    var now = new Date();
    var orderDate = now.getDate() + "/" + (now.getMonth() + 1) + "/" + now.getFullYear();
    var orderTime = now.getHours() + ":" + String(now.getMinutes()).padStart(2, "0");

    // Generate a random Order ID
    var orderId = "ORD" + Math.floor(Math.random() * 9000 + 1000);

    // Get cart data
    var cartItems = JSON.parse(localStorage.getItem("cartItems"));
    var deliveryLocation = localStorage.getItem("deliveryLocation");
    var cartTotal = localStorage.getItem("cartTotal");
    var loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));

    // Create the order object
    var newOrder = {
        orderId: orderId,
        studentName: loggedInUser.name,
        sapId: loggedInUser.sapId,
        items: cartItems,
        total: cartTotal,
        location: deliveryLocation,
        paymentMethod: selectedPayment,
        date: orderDate,
        time: orderTime,
        status: "Order Placed"
    };

    // Step 5: Save this order to order history in localStorage
    var allOrders = localStorage.getItem("orderHistory");
    var ordersArray = [];

    if (allOrders != null) {
        ordersArray = JSON.parse(allOrders);
    }

    ordersArray.push(newOrder);
    localStorage.setItem("orderHistory", JSON.stringify(ordersArray));

    // Step 6: Save the current order ID so the order page can show tracking
    localStorage.setItem("currentOrderId", orderId);
    localStorage.setItem("currentLocation", deliveryLocation);

    // Step 7: Clear the cart from localStorage
    localStorage.removeItem("cartItems");
    localStorage.removeItem("cartTotal");
    localStorage.removeItem("deliveryLocation");

    // Step 8: Go to the order tracking page
    alert("Payment successful! Your Order ID is: " + orderId);
    window.location.href = "order.html";
}
