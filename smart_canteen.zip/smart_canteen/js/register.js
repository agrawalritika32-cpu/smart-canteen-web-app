// ============================================
// register.js
// This file handles student registration
// It saves student info to localStorage (our fake database)
// ============================================


// This function runs when student clicks "Register" button
function registerStudent() {

    // Step 1: Get all the values typed by the user
    var name = document.getElementById("regName").value;
    var sapId = document.getElementById("regSapId").value;
    var studentId = document.getElementById("regStudentId").value;
    var mobile = document.getElementById("regMobile").value;
    var password = document.getElementById("regPassword").value;
    var confirmPassword = document.getElementById("regConfirmPassword").value;

    // Step 2: Get message display elements
    var errorMsg = document.getElementById("regErrorMsg");
    var successMsg = document.getElementById("regSuccessMsg");

    // Step 3: Clear old messages
    errorMsg.innerText = "";
    successMsg.innerText = "";

    // Step 4: Check each field one by one
    if (name == "") {
        errorMsg.innerText = "Please enter your full name.";
        return;
    }

    if (sapId == "") {
        errorMsg.innerText = "Please enter your SAP ID.";
        return;
    }

    if (sapId.length < 8) {
        errorMsg.innerText = "SAP ID must be at least 8 characters.";
        return;
    }

    if (studentId == "") {
        errorMsg.innerText = "Please enter your Student ID.";
        return;
    }

    if (mobile == "") {
        errorMsg.innerText = "Please enter your mobile number.";
        return;
    }

    if (mobile.length != 10) {
        errorMsg.innerText = "Mobile number must be exactly 10 digits.";
        return;
    }

    if (password == "") {
        errorMsg.innerText = "Please enter a password.";
        return;
    }

    if (password.length < 6) {
        errorMsg.innerText = "Password must be at least 6 characters long.";
        return;
    }

    if (confirmPassword == "") {
        errorMsg.innerText = "Please confirm your password.";
        return;
    }

    if (password != confirmPassword) {
        errorMsg.innerText = "Passwords do not match. Please re-enter.";
        return;
    }

    // Step 5: Load existing users from localStorage
    var allUsers = localStorage.getItem("canteenUsers");
    var usersArray = [];

    // If there are already some users saved, load them
    if (allUsers != null) {
        usersArray = JSON.parse(allUsers);
    }

    // Step 6: Check if SAP ID is already registered
    for (var i = 0; i < usersArray.length; i++) {
        if (usersArray[i].sapId == sapId) {
            errorMsg.innerText = "This SAP ID is already registered. Please login instead.";
            return;
        }
    }

    // Step 7: Create a new student object with the 3 main fields: id, sapId, password
    // We also store extra info like name and mobile
    var newStudent = {
        id: usersArray.length + 1,       // Auto number starting from 1
        sapId: sapId,                     // SAP ID (e.g. 60004230001)
        studentId: studentId,             // Roll Number (e.g. 23BCE1234)
        password: password,               // Password
        name: name,                       // Full name
        mobile: mobile                    // Mobile number
    };

    // Step 8: Add new student to the array
    usersArray.push(newStudent);

    // Step 9: Save the updated array back to localStorage
    // JSON.stringify converts the JavaScript object to text so it can be saved
    localStorage.setItem("canteenUsers", JSON.stringify(usersArray));

    // Step 10: Show success message
    successMsg.innerText = "Registration successful! You can now login.";

    // Step 11: Wait 2 seconds and go to login page
    setTimeout(function() {
        window.location.href = "index.html";
    }, 2000);

}
