// ============================================
// contact.js
// This file handles the contact page
// Saves message to localStorage and shows confirmation
// ============================================


// This function runs when student clicks "Send Message"
function sendMessage() {

    // Get the values from the form
    var name = document.getElementById("contactName").value;
    var sap = document.getElementById("contactSap").value;
    var message = document.getElementById("contactMessage").value;

    // Get the message display element
    var msgDisplay = document.getElementById("contactMsg");
    msgDisplay.innerText = "";

    // Check if all fields are filled
    if (name == "") {
        msgDisplay.style.color = "red";
        msgDisplay.innerText = "Please enter your name.";
        return;
    }

    if (sap == "") {
        msgDisplay.style.color = "red";
        msgDisplay.innerText = "Please enter your SAP ID.";
        return;
    }

    if (message == "") {
        msgDisplay.style.color = "red";
        msgDisplay.innerText = "Please write a message.";
        return;
    }

    // Save the message to localStorage
    var now = new Date();
    var newMessage = {
        name: name,
        sap: sap,
        message: message,
        date: now.toLocaleDateString()
    };

    var allMessages = localStorage.getItem("contactMessages");
    var messagesArray = [];

    if (allMessages != null) {
        messagesArray = JSON.parse(allMessages);
    }

    messagesArray.push(newMessage);
    localStorage.setItem("contactMessages", JSON.stringify(messagesArray));

    // Show success message
    msgDisplay.style.color = "green";
    msgDisplay.innerText = "Your message was sent successfully! We will get back to you soon.";

    // Clear the form fields
    document.getElementById("contactName").value = "";
    document.getElementById("contactSap").value = "";
    document.getElementById("contactMessage").value = "";
}
