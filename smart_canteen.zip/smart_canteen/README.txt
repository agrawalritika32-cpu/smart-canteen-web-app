============================================
  SMART CANTEEN - NMIMS Aditi Canteen
  Web Development Project - First Year
  Mukesh Patel School of Technology
============================================


--------------------------------------------
FOLDER STRUCTURE
--------------------------------------------

smart_canteen/
│
├── index.html          --> Login page (homepage)
├── register.html       --> Student registration page
├── menu.html           --> Food menu and cart page
├── payment.html        --> Payment page
├── order.html          --> Order tracking page
├── contact.html        --> Contact page
├── nmims_logo.png      --> Put the NMIMS logo image here
│
├── css/
│   └── style.css       --> ALL styles for the website
│
├── js/
│   ├── login.js        --> JavaScript for login page
│   ├── register.js     --> JavaScript for register page
│   ├── menu.js         --> JavaScript for menu and cart
│   ├── payment.js      --> JavaScript for payment page
│   ├── order.js        --> JavaScript for order tracking
│   └── contact.js      --> JavaScript for contact form
│
├── database/
│   └── database.sql    --> SQL file to create all database tables
│
└── backend/
    └── server.js       --> Node.js backend server (optional)


--------------------------------------------
HOW EACH FILE IS CONNECTED
--------------------------------------------

index.html     --> uses css/style.css and js/login.js
register.html  --> uses css/style.css and js/register.js
menu.html      --> uses css/style.css and js/menu.js
payment.html   --> uses css/style.css and js/payment.js
order.html     --> uses css/style.css and js/order.js
contact.html   --> uses css/style.css and js/contact.js

server.js      --> uses database.sql (connects to MySQL)


--------------------------------------------
HOW TO RUN (SIMPLE - NO BACKEND)
--------------------------------------------

This version uses "localStorage" (browser storage)
as a fake database. No server needed!

Steps:
1. Put all files in the smart_canteen folder
2. Put your NMIMS logo image and name it: nmims_logo.png
3. Double-click index.html to open in browser
4. Register a new account, then login

That's it! Everything works without any server.


--------------------------------------------
HOW TO RUN (WITH NODE.JS BACKEND + MYSQL)
--------------------------------------------

Step 1: Install MySQL
- Download from https://www.mysql.com/downloads/
- Create database by running: database/database.sql

Step 2: Install Node.js
- Download from https://nodejs.org
- Choose the LTS version

Step 3: Install required packages
- Open terminal in the smart_canteen/backend folder
- Run this command: npm install express mysql2 cors

Step 4: Update database password
- Open backend/server.js
- Find the database connection section
- Change password to your MySQL password

Step 5: Start the server
- In terminal, run: node server.js
- You should see: "Server running on http://localhost:3000"

Step 6: Open the website
- Open index.html in browser


--------------------------------------------
DATABASE - 3 REQUIRED FIELDS (SQL)
--------------------------------------------

The students table has these 3 main fields:
- id         : Auto number (1, 2, 3...)
- sap_id     : Student SAP ID (e.g. 60004230001)
- password   : Student password

Plus extra fields: student_id, full_name, mobile


--------------------------------------------
SAMPLE LOGIN CREDENTIALS (for testing)
--------------------------------------------

SAP ID: 60004230001
Student ID: 23BCE1234
Password: pass123

SAP ID: 60004230002
Student ID: 23BCE1235
Password: pass456


--------------------------------------------
FEATURES OF THIS WEBSITE
--------------------------------------------

For Students:
- Register with SAP ID, Student ID, and Password
- Login with credentials (saved in localStorage or MySQL)
- View full canteen menu with categories
- Filter food by: All, Breakfast, Main Course, Snacks, Drinks
- Add food to cart
- Remove food from cart
- Choose delivery: Girls Hostel, Boys Hostel, Classroom
- Pay using: UPI, Debit/Credit Card, Cash on Delivery
- See order confirmation with Order ID
- Track order through 5 steps (live animation)
- View past order history
- Send messages via Contact page


--------------------------------------------
TECHNOLOGIES USED
--------------------------------------------

HTML    --> Structure of all pages
CSS     --> Styling and design (style.css)
JS      --> Interactivity (login, cart, payment etc.)
SQL     --> Database tables and queries
Node.js --> Backend server (optional, server.js)


============================================
  Made with care for Web Development Class
  NMIMS - Mukesh Patel School of Technology
============================================
